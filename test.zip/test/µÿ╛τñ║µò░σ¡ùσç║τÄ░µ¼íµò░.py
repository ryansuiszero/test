n = int(input())
f = input()
s = "{:0x}".format(n)
dic = {}
for c in s:
    dic[c] = dic.get(c, 0)+1
print(dic.get(f, 0))
