ls = eval(input())  # 把输入转换成列表，而不是直接用字符的方式处理


def s(ls, level):  # 传入一个列表和当前的层数
    sum = 0  # 加权和，初始化为0
    for i in ls:  # 遍历列表中每一个元素
        if type(i) == int:  # 如果这个元素的类型是整数形
            sum += i*level  # 就计算它的加权和
        else:  # 如果不是整数型，说明它是一个列表
            sum += s(i, level+1)  # 那么就进行下一层次的加权和
    return sum  # 最后返回加权和


sum = s(ls, 1)  # 刚开始是在第一层
print(sum)
