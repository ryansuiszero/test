row = int(input())
for i in range(1, row+1):
    for col in range(i):
        print(chr(ord("A")+col), end="")
    print()
