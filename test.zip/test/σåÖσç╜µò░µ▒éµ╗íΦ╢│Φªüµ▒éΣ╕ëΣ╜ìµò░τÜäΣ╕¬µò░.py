def search(n):
    sum = 0
    for i in range(11, 33):
        if pow(i, 2) <= n:
            if str(pow(i, 2)).count('0') == 2 or str(pow(i, 2)).count('1') == 2 or str(pow(i, 2)).count(
                '2') == 2 or str(pow(i, 2)).count('3') == 2 or str(pow(i, 2)).count('4') == 2 or str(
                    pow(i, 2)).count('5') == 2 or str(pow(i, 2)).count(
                    '6') == 2 or str(pow(i, 2)).count('7') == 2 or str(pow(i, 2)).count('8') == 2 or str(pow(i, 2)).count(
                    '9') == 2:
                sum += 1
    return sum
