import math

m, n = map(int, input().split())
t = True  # 判断是否有完数
for k in range(m, n + 1):
    num = [1]
    for a in range(2, int(math.sqrt(k)) + 1):
        if k % a == 0:
            num.append(a)
            if a * a != k:  # 这里是防止前面找到的因数被重复加入列表
                num.append(k // a)  # 通过整除找到后面对应的一个因数
    if sum(num) == k:
        t = False
        num.sort()
        print(k, "=", end=' ')
        print(*num, sep=" + ")
if t:
    print("None")
