a, b = input().split()

a, b = int(a), int(b)
s1 = set([i for i in range(a, b+1) if i % 3 == 0])

s2 = set([i for i in range(a, b+1) if i % 5 == 0])

s3 = set([i for i in range(a, b+1) if i % 7 == 0])

print(len(s1 & s2 & s3))
