nums = list(map(int, input().split(',')))
target = int(input())

hm = dict()
for i in range(len(nums)):
    if nums[i] in hm:
        print(hm[nums[i]], i)
        break
    hm[target - nums[i]] = i
else:
    print("no answer")
