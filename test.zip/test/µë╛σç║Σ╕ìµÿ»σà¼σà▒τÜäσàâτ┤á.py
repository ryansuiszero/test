lst1 = input().split()
lst2 = input().split()
first = [t for t in lst1 if t not in lst2]
second = [t for t in lst2 if t not in lst1]
print(" ".join(first+second))
