def y(k,x,n):
    sum=0
    for i in k:
        if isinstance(i,int) and x==n:
            sum+=1
        elif isinstance(i,list):
            sum+=y(i,x+1,n)
    return sum
k=eval(input())
x=1
n=int(input())
print(y(k,x,n))