n = int(input())  # 输入矩阵个数
for number in range(n):  # 对于每个矩阵
    m = int(input())
    mat = []
    for row in range(m):
        mat.append(input().split())
    lstupper = [int(mat[i][j]) for i in range(m)
                for j in range(m) if i < j]  # 取上三角元素
    lstlower = [int(mat[i][j]) for i in range(m)
                for j in range(m) if i > j]  # 取下三角元素

    if len([i for i in lstlower if i != 0]) == 0:
       print("upper triangular matrix")
    elif len([i for i in lstupper if i != 0]) == 0:
       print("lower triangular matrix")
    else:
       print("no")
