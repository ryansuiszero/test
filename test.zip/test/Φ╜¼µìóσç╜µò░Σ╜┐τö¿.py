x, y = eval(input())
print(int(str(x), y))
