a, b, c = input().split()
a, b, c = int(a), int(b), int(c)
if a > b:
   a, b = b, a
if b > c:
   b, c = c, b
if a > b:
   a, b = b, a
print("{}<{}<{}".format(chr(a), chr(b), chr(c)))
