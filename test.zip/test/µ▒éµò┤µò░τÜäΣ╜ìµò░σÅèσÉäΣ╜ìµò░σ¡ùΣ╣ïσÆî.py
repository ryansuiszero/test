n = int(input())
lst = [int(c) for c in str(n)]
print(len(lst), sum(lst))
