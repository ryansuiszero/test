t = int(input())
start = 10**(t-1)
end = 10**t-1
for i in range(start, end+1):
  if i == sum([int(j)**len(str(i)) for j in str(i)]):
     print(i)
