xiaofei = int(input())
xiaofei = xiaofei/12
if xiaofei < 2000:  # 判断消费等级
    b = 1
elif xiaofei < 3000:
    b = 2
elif xiaofei < 4000:
    b = 3
elif xiaofei < 5000:
    b = 4
else:
    b = 5
for i in range(0, b):  # 循环输出b个*
    print("*", end="")    # end语句可以让下次输出不换行且可以在输出后加上指定字符
