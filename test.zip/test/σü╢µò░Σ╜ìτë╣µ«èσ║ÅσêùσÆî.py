a, n = input().split()
n = int(n)
total = sum([int(a*i) for i in range(1, n+1) if i % 2 == 0])
print(total)
