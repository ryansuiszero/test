lim, com, age1, age2 = map(int, input().split())
max = max([age1, age2])
min = min([age1, age2])
if age1 < lim and age2 >= com:
    print(f"{age1}-Y {age2}-Y")
    print(f"qing 2 zhao gu hao 1")
if age2 < lim and age1 >= com:
    print(f"{age1}-Y {age2}-Y")
    print(f"qing 1 zhao gu hao 2")
if min >= lim:
    print(f"{age1}-Y {age2}-Y")
    print('huan ying ru guan')
if max < lim:
    print(f"{age1}-N {age2}-N")
    print('zhang da zai lai ba')
if com > age1 >= lim and age2 < lim:
    print(f"{age1}-Y {age2}-N")
    print('1: huan ying ru guan')
if com > age2 >= lim and age1 < lim:
    print(f"{age1}-N {age2}-Y")
    print('2: huan ying ru guan')
