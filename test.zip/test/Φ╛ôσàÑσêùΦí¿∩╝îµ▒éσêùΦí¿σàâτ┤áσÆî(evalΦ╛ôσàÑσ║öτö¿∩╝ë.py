lst = eval(input())
s = sum([int(i) for i in lst])
print(s)
