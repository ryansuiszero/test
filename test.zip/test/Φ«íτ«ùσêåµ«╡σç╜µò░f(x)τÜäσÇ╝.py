x = float(input())
y = float(0)

if x == 0:
    print("f(0.0)=0.000", end="")
else:
    y = 1 / x
    print(f"f({x:.2f})={y:.3f}", end="")
