m, n = map(int, input().split())
count = 0
for i in range(m, n+1):
    s = [k for k in range(1, i) if i % k == 0]
    if sum(s) == i:
        s.sort()
        print("%d = %s" % (i, " + ".join(map(str, s))))
        count += 1
if count == 0:
    print("None")
