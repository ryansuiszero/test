sen = input()
a, b = input().split()
lst = [(i, sen[i]) for i in range(len(sen)) if sen[i] == a or sen[i] == b]
lstnew = lst[::-1]
for i in range(len(lstnew)):
    print(lstnew[i][0], lstnew[i][1])
