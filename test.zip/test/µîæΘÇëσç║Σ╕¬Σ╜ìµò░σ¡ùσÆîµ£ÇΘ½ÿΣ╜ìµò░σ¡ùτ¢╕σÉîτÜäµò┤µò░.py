a = input().split(' ')
out_a = []
for i in a:
    if i[0] == i[-1]:
        out_a.append(i)
print(' '.join(out_a))
