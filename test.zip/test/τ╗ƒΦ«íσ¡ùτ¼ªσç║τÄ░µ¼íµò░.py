s = input()
a = input()
cnt = 0
for i in s:
    if(i == a):
        cnt = cnt+1
print(cnt)
