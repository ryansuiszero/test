import math

app = float(input())
s = 1
i = 2
while True:
  item = 1/(i*i)
  if item < app:
     break
  else:
     s = s+item
     i = i+1
print("{:.6f}".format(math.sqrt(6*s)))
