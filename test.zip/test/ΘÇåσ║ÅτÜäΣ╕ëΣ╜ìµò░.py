a = input()
print(int(a[::-1]))
