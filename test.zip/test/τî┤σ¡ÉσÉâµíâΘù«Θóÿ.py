m = int(input())
x = 1
for i in range(10, 0, -1):
    if (11 - i) == m:
        print(x)
    x = 2 * (x + 1)
