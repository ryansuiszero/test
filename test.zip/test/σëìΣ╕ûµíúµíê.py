x, y = map(int, input().split())
for i in range(y):
    a = input()
    f = 1
    for i in a:
        if i == 'y':
            f = f*2-1
        else:
            f *= 2
    print(f)
