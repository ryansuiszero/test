x = eval(input())


def Sum(x):
    sums = 0
    for ch in x:
        if isinstance(ch, int):
            sums += ch
        if isinstance(ch, list):
            sums += Sum(ch)  # 列表中嵌套层次不限2层,要用递归
        if isinstance(ch, tuple):
            sums += Sum(ch)  # 列表中嵌套层次不限2层,要用递归
    return sums
print(Sum(x))
