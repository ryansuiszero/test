lower, upper = input().split()
lower, upper = int(lower), int(upper)
if lower < -20 or upper > 50:
    print("Invalid.")
else:
    print("celsius    fahr")
    for i in range(lower, upper, 2):
        f = i*1.8+32
        print("{:d}{:14.1f}".format(i, f))
