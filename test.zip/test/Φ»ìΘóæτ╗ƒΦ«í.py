# 导入库
import re
import collections
import sys

words = "".join([line for line in sys.stdin])  # 标准输入sys.stdin读入文本
# 正则表达式将文本处理成全小写并读到符号#
words = re.compile(r"\w+", re.I).findall(words.lower().split('#')[0])
words = [each.strip() for each in words]  # 去除空格
# 长度超过15的单词将只截取保留前15个单词字符
words = list(map(lambda each: each[0:15] if len(each) > 15 else each, words))
counter = collections.Counter(words)  # 使用Counter统计词频
rank = sorted(counter.items(),
              key=lambda each: (-each[1], each[0]), reverse=False)  # 按照词频递减排序
print(len(rank))  # 输出不同单词的个数
for each in rank[0:int(0.1*len(rank))]:  # 输出词频最大的前10%的单词
    print("{}:{}".format(each[1], each[0]))
