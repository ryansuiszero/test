def isflower(n):
  lis = []
  for i in str(n):
    lis.append(i)
  if int(lis[0])**3+int(lis[1])**3+int(lis[2])**3 == n:
    return True
  else:
    return False

    n = eval(input("输入N"))
    if 100 <= n <= 999:
      if isflower(n) == True:
        print('Yes')
      else:
        print('No')
    else:
      print("输入的数字不对")
