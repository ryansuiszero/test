s = input().strip()
result = ""
for c in s:
    if "a" <= c <= "z" or "A" <= c <= "Z":
        if c.lower() not in result and c.upper() not in result:
            result = result+c
if len(result) >= 10:
    print(result[:10])
else:
    print("not found")
