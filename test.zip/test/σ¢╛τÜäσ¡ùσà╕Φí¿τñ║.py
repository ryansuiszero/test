n = int(input())
vertex = 0
edge = 0
length = 0
for i in range(n):
    l = input()
    d = eval(l)
    for key1 in d:
        vertex += 1
        for key2 in d[key1]:
            edge += 1
            length += d[key1][key2]
print(vertex, edge, length)
