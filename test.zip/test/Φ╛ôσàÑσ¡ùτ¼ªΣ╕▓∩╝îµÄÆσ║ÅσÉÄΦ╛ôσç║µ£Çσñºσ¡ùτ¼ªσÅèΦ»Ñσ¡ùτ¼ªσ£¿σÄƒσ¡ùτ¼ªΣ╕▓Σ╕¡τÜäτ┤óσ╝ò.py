s = input()
lst = [(s[index], index) for index in range(len(s))]
lst.sort()
print(lst[-1][0], " ", lst[-1][1])
