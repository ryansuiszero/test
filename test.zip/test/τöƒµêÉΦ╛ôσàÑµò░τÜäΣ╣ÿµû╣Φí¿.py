x, n = input().split()
x = float(x)
n = int(n)
for i in range(n+1):
    print("{:}**{:}={:.2f}".format(x, i, x**i))
