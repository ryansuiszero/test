N = int(input())
stand = []
for i in range(1, N+1):
    stand.append(1)  # 所有猴子都在
cnt = 0
n = N
while(n != 1):
    for i in range(0, N):
        if stand[i] == 1:  # 这个猴子还在才计数
            cnt = cnt+1
            if cnt == 3:
                stand[i] = 0
                cnt = 0
                n = n-1  # 猴子数量减一
print(stand.index(1)+1)
