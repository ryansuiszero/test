def Fun_Fact(x):  # 定义阶乘函数，对x求阶乘
    sum = 1
    for i in range(1, x + 1):
        sum *= i
    return sum


def Fun_Comb(m, n):  # 调用阶乘函数，使用题目公式，再设计函数计算组合数
    sum = Fun_Fact(n) / (Fun_Fact(m) * Fun_Fact(n - m))
    return sum
