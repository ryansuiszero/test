def f(x, s=""):
	s += x
	if len(s) < n:
		for i in num:
			if i not in s:
				f(i, s)
	else:
		print(s)


n = int(input())
num = [str(i+1) for i in range(n)]
for i in num:
	f(i)
