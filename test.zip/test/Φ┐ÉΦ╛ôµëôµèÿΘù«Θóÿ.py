w, s = map(float, input().split())
if 0 <= s < 250:
    p = w*s
elif 250 <= s < 500:
    p = w*s*0.98
elif 500 <= s < 1000:
    p = w*s*0.95
elif 1000 <= s < 2000:
    p = w*s*0.92
elif 2000 <= s < 3000:
    p = w*s*0.9
else:
    p = w*s*0.85
print("{:.0f}".format(p))
