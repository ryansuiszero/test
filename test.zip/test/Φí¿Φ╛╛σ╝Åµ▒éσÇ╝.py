import math  # 导入math库，或用from math import *方法导入
a, b, c = 5, 8, 3
x = (math.sqrt(b*b-4*a*c)-b)/(2*a)  # math库sqrt(x)函数，返回x的平方根
print("{}".format(x))
