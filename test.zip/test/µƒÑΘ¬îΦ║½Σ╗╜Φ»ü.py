N = int(input())
flag = 1
M = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']  # 注意x为大写
rate = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
sum = 0
for i in range(0, N):
    s = input()
    sum = 0
    flag1 = 1  # 检测前17位是否全为数字
    flag2 = 1  # 判断是否计算准确
    for k in range(0, 17):
        if s[k] >= '0' and s[k] <= '9':
            sum = sum+int(s[k])*rate[k]
        else:
            flag1 = 0
            break
    if M[sum % 11] != s[17]:
        flag2 = 0
    if flag1 == 0 or flag2 == 0:  # 前17位不全为数字或者计算不准确
        flag = 0
        print(s)
if flag == 1:
    print("All passed")
