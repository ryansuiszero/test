lst = eval(input())
seen = set()
lst1 = [i for i in lst if i not in seen and not seen.add(i)]
print(*lst1)
