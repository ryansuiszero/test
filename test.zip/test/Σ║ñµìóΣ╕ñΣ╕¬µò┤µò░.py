a, b = input().split()
a, b = b, a
print(f"a={a} b={b}")
