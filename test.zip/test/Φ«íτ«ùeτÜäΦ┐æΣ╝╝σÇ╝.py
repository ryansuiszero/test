error = float(input())
a = 1
i = 2
t = 2
b = 1/t
sum = 2
e1 = 1
e2 = sum
while e2-e1 >= error:
    e1 = e2
    a = b
    sum += a
    e2 = sum
    i += 1  # 阶乘计数
    t *= i  # 阶乘值
    b = 1/t
print("{}".format(sum))
