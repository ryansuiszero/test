def y(k,x):
    sum=0
    for i in k:
        if isinstance(i,int):
            sum+=1*x
        elif isinstance(i,list):
            sum+=y(i,x+1)
    return sum
k=eval(input())
x=1
print(y(k,x)) 