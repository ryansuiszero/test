while True:
    try:
       lp = input()
       ls = lp.split(" ")
       for i in range(len(ls)):
           ls[i] = ls[i].capitalize()
    except:
       break
    print(' '.join(ls))
