def isHd(n):
    num_str = str(n)
    max = ""
    min = ""
    for it in sorted(num_str, reverse=True):
        max += str(it)
    for it in sorted(num_str):
        min += str(it)
    if int(max) - int(min) == n:
        return True
    else:
       return False
