num = [[1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6],
       [1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6]]
x = list(map(int, input().split()))
n = int(input())
for i in range(0, 6):
    num[i][x[i] - 1] = 0
    num[i] = sorted(num[i], reverse=True)
for i in range(5):
    print(num[i][n - 1], end=' ')
print(num[5][n - 1])
