m,n = map(int,input().split())
def gongyue(a,b):
    while True:
        if a<b:
            a,b=b,a
        a,b=b,a%b
        if b==0:
            return a
            break 

def gongbei(a,b,c):
    return int(a*b/c)

gongyue_max = gongyue(m,n)
gongbei_min = gongbei(m,n,gongyue_max)
print(gongyue_max,gongbei_min)