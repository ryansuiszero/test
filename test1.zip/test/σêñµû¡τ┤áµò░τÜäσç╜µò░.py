def prime(m):
    i = 2
    while i < m:
        if m % i == 0:
            return False
        i += 1
    else:
        return True
