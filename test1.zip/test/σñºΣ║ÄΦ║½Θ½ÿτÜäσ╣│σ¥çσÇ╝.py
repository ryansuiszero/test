l = input().split()
l1 = [int(i) for i in l]
aver = sum(l1)/len(l1)
l2 = [i for i in l1 if i > aver]
for i in l2:
   print(i, end=' ')
