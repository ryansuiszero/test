import math

m, n = input().split()
m, n = int(m), int(n)
s = sum([i*i+1/i for i in range(m, n+1)])
print("sum ≈ {}".format(math.floor(s)))
