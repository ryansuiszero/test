#编写一个函数，判断输入的字符串是否由小写字母和数字组成
char = input()
length = len(char)
a = 0  # 用于记录在ASCII码内并累加，最后和字符串长度一致则认为是以下结论
b = 0
for i in char:
    num = ord(i)  # ord（）把字符串转为ASCII码
    if 48 <= num <= 57:   # 对应ASCII码的数字值
        a += 1  # 在范围内就累加
    if 97 <= num <= 122:   # 对应ASCII码的小写字母
        b += 1
c = a + b
if c == length:  # 判断累加结果与字符串长度
    print("全是数字和小写字母")
else:
    print("不全是数字和小写字母")
