lst = input().split()
mat = [[int(lst[col]) for col in [0+row*3, 1+row*3, 2+row*3]]
       for row in [0, 1, 2]]
maxrow = max(sum(row) for row in mat)
maxcol = max([sum([mat[row][col] for row in [0, 1, 2]]) for col in [0, 1, 2]])
maxdig = max(sum([mat[0][0], mat[1][1], mat[2][2]]),
             sum([mat[0][2], mat[1][1], mat[2][0]]))
print(max(maxrow, maxcol, maxdig))
