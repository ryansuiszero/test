def change( money ):
    s=eval(money[1:])
    if(money[0]=='$'):
        print('{}美元 = {:.2f}人民币'.format(s,s*6.709))
    elif(money[0]=='￥'):
        print('{}人民币 = {:.2f}美元'.format(s,s/6.709))