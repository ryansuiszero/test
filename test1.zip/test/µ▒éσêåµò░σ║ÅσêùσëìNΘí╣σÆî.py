def fenmu(n):
    a, b = 2, 1
    for i in range(n):
        a, b = a+b, a
    return a


def fenzi(n):
    a, b = 2, 1
    for i in range(n):
        a, b = a+b, a
    return b


n = int(input())
if n == 1:
    print("2.00")
    exit(0)
sum = 0.00
for i in range(n):
    sum += fenmu(i)/fenzi(i)
print("{:.2f}".format(sum))
