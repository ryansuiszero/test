import math
T = int(input())


def shushu(m, k):
    if (m == 1):
        print("no")
    else:
        for i in range(2, k+2):
            if m % i == 0:
                break
        if i == k+1:
            print("yes")
        else:
            print("no")


for i in range(0, T):
    m = int(input())
    k = int(math.sqrt(m))
    shushu(m, k)
