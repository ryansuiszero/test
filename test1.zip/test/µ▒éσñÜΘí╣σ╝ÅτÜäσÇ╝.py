def polyvalue(lst, a):
    sum = 0
    for b in range(len(lst)):
        sum += lst[b]*pow(a, b)

    return sum
