def sum_func(*args):
    total = 0
    for i in args:
        total += i
    return total
