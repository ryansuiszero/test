import math

x = float(input())
y = math.sin(35/180*math.pi)+(math.e**x-15*x)/math.sqrt((x**4+1))-math.log(7*x)

print("f({0})={1:.3f}".format(x, y))
