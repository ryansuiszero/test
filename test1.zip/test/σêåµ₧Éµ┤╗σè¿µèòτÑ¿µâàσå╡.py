s = {"6", "7", "8", "9", "10"}-set(input().split(","))
lst = list(s)
lst = [int(i) for i in lst]
lst.sort()
print(*lst)
