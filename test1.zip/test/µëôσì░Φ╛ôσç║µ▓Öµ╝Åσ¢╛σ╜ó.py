x = int(input())

for i in range(x - 1):
    print(f"{' ' * i}", end="")
    print(f"{'*' * ((x - i) * 2 - 1)}")
for j in range(x - 1, -1, -1):
    print(f"{' ' * j}", end="")
    print(f"{'*' * ((x - j) * 2 - 1)}")
