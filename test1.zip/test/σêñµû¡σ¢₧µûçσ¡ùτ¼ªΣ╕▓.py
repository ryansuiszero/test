s = input()
lst1 = [t.lower() for t in s if t.isdigit() or t.isalpha()]
s1 = "".join(lst1)
if s1 == s1[::-1]:
   print("yes")
else:
   print("no")
