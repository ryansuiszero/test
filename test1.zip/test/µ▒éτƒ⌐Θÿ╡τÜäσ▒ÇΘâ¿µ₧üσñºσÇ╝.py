a,b = input().split(" ")
m = int(a)
n = int(b)
l = list()
for i in range(0,m):
    s = list(map(int,input().split(" ")))
    l.append(s)

key = True
for i in range(1,m-1):
        for j in range(1,n-1):
                if l[i][j] > l[i-1][j] and l[i][j] > l[i+1][j] and l[i][j] > l[i][j+1] and l[i][j] > l[i][j-1]:
                    print(l[i][j],i+1,j+1)
                    key = False
if key:
    print("None",m,n)