a = int(input())
if(a <= 15):
    print("{:.2f}".format(4*a/3))
else:
    print("{:.2f}".format(2.5*a-17.5))
