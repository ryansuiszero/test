name = input()
print("你好，"+name+"同学。")
print(name[0]+"同学，很高兴认识你。")
print(name[1:len(name)]+"同学，我们交个朋友吧！")
