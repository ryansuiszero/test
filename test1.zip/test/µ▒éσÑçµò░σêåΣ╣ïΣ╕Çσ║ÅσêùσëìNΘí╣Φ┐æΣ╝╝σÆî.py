import math

n = int(input())
s = sum([1/(2*i+1) for i in range(0, n)])
print("sum ≈ {}".format(math.ceil(s)))
