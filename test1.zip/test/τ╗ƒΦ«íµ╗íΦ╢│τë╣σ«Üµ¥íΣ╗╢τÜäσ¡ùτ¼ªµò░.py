s = input()
con = input()
print(len([c for c in s if c in con]))
