x = float(input())
if int(x) != 0:
   y = 1/(2*x)
else:
   y = 0
print("g({0:.3f}) = {1:.3f}".format(x, y))
