def fn(a, b):
    s = sum([int(str(a)*i) for i in range(1, b+1)])
    return(s)
