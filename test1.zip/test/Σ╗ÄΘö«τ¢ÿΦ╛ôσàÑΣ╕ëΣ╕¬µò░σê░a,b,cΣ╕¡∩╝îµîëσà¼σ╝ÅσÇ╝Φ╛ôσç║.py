a, b, c = input().split()
print(int(b)*int(b)-4*int(a)*int(c))
