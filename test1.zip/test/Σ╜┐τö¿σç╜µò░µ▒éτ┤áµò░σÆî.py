def prime(p):
   if p == 1:
      return False
   else:
      return(not any([False if p % k != 0 else True for k in range(2, p-1)]))


def PrimeSum(m, n):
   return(sum([k for k in range(m, n+1) if prime(k)]))
