d1 = eval(input())
d2 = eval(input())
d3 = {}
c = 0
for i in d1:
    if i in d2:
        d2[i] += d1[i]
    else:
        d2[i] = d1[i]
for k in d2:
    if type(k) == type("a"):
        d3[ord(k)] = 0
    if type(k) == type(1):
        d3[k] = 1
print('{', end='')
for j in sorted(d3):
    c += 1
    if d3[j] == 0:
        print('"{}":{}'.format(chr(j), d2[chr(j)]), end='')
    if d3[j] == 1:
        print('{}:{}'.format(j, d2[j]), end='')
    if c < len(d3):
        print(',', end='')
print('}')
