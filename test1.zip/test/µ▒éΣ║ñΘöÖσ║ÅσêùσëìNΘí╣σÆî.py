n = int(input())
sum = 0
flag = 1
for i in range(1, n + 1):
    sum += float(i) / (i * 2 - 1) * flag
    flag = -flag
print("%.3f" % sum)
