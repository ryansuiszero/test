n = int(input())
pre = 1
cur = 1
while cur <= n:
    pre, cur = cur, pre+cur
print(cur)
