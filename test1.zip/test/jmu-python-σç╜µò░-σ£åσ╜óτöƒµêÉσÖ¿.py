import math


def getCircleArea(r):
    return math.pi*r*r


def get_rList(n):
    list = []
    for i in range(n):
        x = eval(input())
        list.append(x)
    return list
