m, n = input().split()
m = int(m)
n = int(n)
if m == 1:    # 1不是素数
    m = 2
prime = []  # 记录已知素数的列表
for x in range(2, n+1):
    for k in prime:
        if x % k == 0:
            break
    else:
        prime.append(x)  # 加入已知素数的列表
lst = [i for i in prime if i >= m and i <= n]
count = 0
for i in range(len(lst)):
    print(lst[i], end=" ")
    count += 1
    if count % 5 == 0:
        print()

if count != 0 and count % 5 != 0:
    print()
print("amount={}".format(len(lst)), "sum={}".format(sum(lst)))
