m, n = input().split()
m = float(m)
n = float(n)
if m > 50:
    print("cost = {:.2f}".format(50*0.53+(m-50)*(0.53+n)))
else:
    print("cost = {:.2f}".format(m*0.53))
