n = int(input())
s = bin(n)
lst = [int(i) for i in s[2:]]
print(sum(lst))
