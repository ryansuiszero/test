n = int(input())
for i in range(n):
  p = int(input())
  if p == 1:
    print('No')
  else:
    if [j for j in range(1, p+1) if p % j == 0] == [1, p]:
      print('Yes')
    else:
      print('No')
