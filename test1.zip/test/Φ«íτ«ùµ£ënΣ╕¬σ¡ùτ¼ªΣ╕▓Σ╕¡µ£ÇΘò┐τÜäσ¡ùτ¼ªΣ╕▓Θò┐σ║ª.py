n = int(input())
l = max([len(input().strip()) for i in range(n)])
print("length=%d" % l)
