s = input().strip()
a = input().strip()
s1 = ''.join([i for i in s if i not in [a.lower(), a.upper()]])
print("result:", s1)
