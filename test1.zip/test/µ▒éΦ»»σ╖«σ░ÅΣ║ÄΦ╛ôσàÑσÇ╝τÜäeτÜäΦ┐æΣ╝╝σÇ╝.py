import math

error = float(input())
pre = 1
cur = 2
i = 2
while cur-pre >= error:
   pre = cur
   cur = pre+1/math.factorial(i)
   i = i+1
print(format(cur, ".6f"))
