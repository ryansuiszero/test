a, b = input().split(',')
print(int(str(int(a))*int(b)))
