import math


def funcos(eps, x):
    i = 0
    s = 0
    flag = 1
    while True:
       item = x**i/math.factorial(i)
       if abs(item) >= eps:
           s = s+flag*item
           flag = -flag
           i = i+2
       else:
           break
    return s
