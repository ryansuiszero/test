str1 = input()
str2 = input()
l1, l2 = list(str1), list(str2)
l1.sort()
l2.sort()
if l1 == l2:
   print("yes")
else:
   print("no")
