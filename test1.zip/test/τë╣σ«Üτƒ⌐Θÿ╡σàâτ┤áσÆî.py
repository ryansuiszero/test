n = int(input())
mat = []
for row in range(n):
   mat.append(input().split())
result = []
for row in range(n):
   for col in range(n):
       if row == col or row+col == n-1:
          result.append((float(mat[row][col])))

print("{:.2f}".format(sum(result)))
