m = int(input())
for row in range(1, m+1, 2):
    print('{:^11}'.format('*'*row))
for row in range(m-2, 0, -2):
    print('{:^11}'.format('*'*row))
